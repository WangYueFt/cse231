#include <iostream>
#include <map>
#include <set>

using namespace std;

map<string, int> funcMap;
map<string, int> takenMap;
set<string> funcNameSet;

void print(){ 

	for(set<string>::iterator iter = funcNameSet.begin(); iter != funcNameSet.end(); iter++ ){
		cout << *iter << "\t";
		map<string, int>::iterator ifunc = funcMap.find(*iter);
		if (ifunc != funcMap.end()) {
			cout << ifunc->second << "\t";
		} else {
			cout << 0 << "\t";
		}
		map<string, int>::iterator itaken = takenMap.find(*iter);
		if (itaken != takenMap.end()) {
			cout << itaken->second << "\n";
		} else {
			cout << 0 << "\n";
		}
	}
}

void funcName(char* funcName) {
	
	funcNameSet.insert(funcName);
}

void branch(char* funcName, bool isTrue){

	map<string, int>::iterator it = funcMap.find(funcName);
	if (it == funcMap.end()){
		funcMap.insert(pair<string, int>(funcName, 1));
	} else {
		it->second++;
	}

	if (isTrue) {
		it = takenMap.find(funcName);
		if (it == takenMap.end()){
			takenMap.insert(pair<string, int>(funcName, 1));
		} else {
			it->second++;
		}
	}

}
