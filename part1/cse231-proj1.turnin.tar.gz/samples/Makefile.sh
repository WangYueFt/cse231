llvm:
	make -C /cse231/llvm/build/lib/CSE231
	cp /cse231/llvm/src/lib/CSE231/dynamic.bc /cse231/samples/.

bench:
	clang -O0 -emit-llvm -c /cse231/extra/benchmarks/gcd/gcd.cpp -o /cse231/extra/benchmarks/gcd/gcd.bc
	cd /cse231/extra/benchmarks/compression
	make 
	cd /cse231/extra/benchmarks/hadamard
	make
	clang -O0 -emit-llvm -c /cse231/extra/benchmarks/welcome/welcome.cpp -o /cse231/extra/benchmarks/welcome/welcome.bc

opt:
	opt -load /cse231/llvm/build/Release+Asserts/lib/CSE231.so -branch < /cse231/extra/benchmarks/gcd/gcd.bc > /cse231/samples/gcd.bc
	opt -load /cse231/llvm/build/Release+Asserts/lib/CSE231.so -branch < /cse231/extra/benchmarks/compression/compression.bc > /cse231/samples/compression.bc
	opt -load /cse231/llvm/build/Release+Asserts/lib/CSE231.so -branch < /cse231/extra/benchmarks/hadamard/hadamard.bc > /cse231/samples/hadamard.bc
	opt -load /cse231/llvm/build/Release+Asserts/lib/CSE231.so -branch < /cse231/extra/benchmarks/welcome/welcome.bc > /cse231/samples/welcome.bc
