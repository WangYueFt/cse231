#include <stdio.h>

int main() {
    printf("Welcome to CSE231!\n");
    return 0;
}
