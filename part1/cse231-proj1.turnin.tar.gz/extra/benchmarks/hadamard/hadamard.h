#ifndef HADAMARD_H
#define HADAMARD_H

typedef unsigned short DTYPE;

unsigned int fastWalshTransform(DTYPE*, DTYPE*, DTYPE);

#endif