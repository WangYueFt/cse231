./run-part1.sh $BENCHMARKS/gcd
./run-part1.sh $BENCHMARKS/compression
./run-part1.sh $BENCHMARKS/welcome
./run-part1.sh $BENCHMARKS/hadamard

./run-part2.sh $BENCHMARKS/gcd
./run-part2.sh $BENCHMARKS/compression
./run-part2.sh $BENCHMARKS/welcome
./run-part2.sh $BENCHMARKS/hadamard

./run-part3.sh $BENCHMARKS/gcd
./run-part3.sh $BENCHMARKS/compression
./run-part3.sh $BENCHMARKS/welcome
./run-part3.sh $BENCHMARKS/hadamard